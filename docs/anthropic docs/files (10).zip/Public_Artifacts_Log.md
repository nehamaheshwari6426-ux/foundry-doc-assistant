# Public Artifacts Log

A simple chronological log of public-facing work — LinkedIn posts, talks, articles, repos, podcast appearances, anything externally visible. Used to track Year 1 (and beyond) visibility track progress and to compile evidence for retrospectives, performance reviews, and case studies.

| | |
|---|---|
| **Started** | 2026-05-24 |
| **Year 1 target** | 40+ LinkedIn posts, 1+ talk, 3 public repos, by W48 |

---

## How to use this

- **Log entries close to the event** — link, date, type, brief description, any traction signal worth noting (engagement, DMs received, citations, etc.).
- **Don't curate or filter.** Even small posts that flopped belong here — they're evidence of cadence.
- **Quarterly review** — scan the log for patterns (what landed, what didn't, what voice resonates) and adjust the visibility plan accordingly.
- **At Year 1 retro (W48)**, this log is the source of truth for what was actually shipped publicly.

---

## Format per entry

```
### YYYY-MM-DD — [Type] Title

- **Link:** URL
- **Type:** LinkedIn post / Article / Talk / Repo / Podcast / Other
- **Topic:** One-line description
- **Voice:** [e.g. lesson-led, methodology-driven, narrative]
- **Traction:** Engagement signal so far (likes, comments, DMs, reposts)
- **Notes:** Anything worth remembering about how it landed
```

---

## Entries

### 2026-05-24 — [LinkedIn post] AI projects punish silent assumptions

- **Link:** https://www.linkedin.com/posts/neha-maheshwari_aidelivery-aileadership-aiprojects-share-7464198668917743616-C2HD/
- **Type:** LinkedIn post
- **Topic:** Lesson on verification checks in AI delivery, anchored in the `articles/foundry/` consolidation finding from W2.
- **Voice:** Lesson-led, business/AI-Lead audience. Final published version was more LinkedIn-formal than the drafted voice — softened by LinkedIn's writing assist or final-pass editing.
- **Traction:** Just published; no signal yet.
- **Notes:** First LinkedIn post in the Year 1 visibility track. Earlier drafts were too technical for business readership; the published version is correctly pitched to AI Leads and curious business readers. Voice gradient observed: authentic → audience-adjusted → platform-flattened — future posts should stop at audience-adjusted.

---

## Year 1 progress tracking

| Category | Target | Current | Notes |
|---|--:|--:|---|
| LinkedIn posts | 40+ | 1 | Started W3. ~45 weeks of cadence remaining. |
| Long-form articles | 2-3 | 0 | First eligible W18 per Year 1 plan ("How I'd run evals for an enterprise AI program"). |
| Case studies | 1 | 0 | Project 1 case study lands W12. |
| Talks delivered | 1+ | 0 | First eligible W34 per Year 1 plan. |
| Public repos | 3 | 1 | foundry-doc-assistant. Project 2 (eval harness) opens W13. |
| Meetups attended | 4+ | 0 | First eligible W12. |

*Updated on each new entry. The target column reflects Year 1 Plan deliverables; current column reflects actuals from this log.*
