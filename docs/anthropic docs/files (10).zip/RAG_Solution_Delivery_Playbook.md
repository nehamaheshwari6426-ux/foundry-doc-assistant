# RAG Solution Delivery Playbook

A project lead's playbook for delivering high-quality retrieval-augmented generation (RAG) systems. Specifies what to decide before building, what to build, how quality is maintained at each step, and how each delivery phase is judged ready and done.

| | |
|---|---|
| **Version** | 0.1 |
| **Status** | Working draft — refined as projects expose gaps |
| **Last updated** | 2026-05 |
| **Companion to** | `AI_Delivery_Lifecycle.md` (general methodology), `AI_Delivery_Lifecycle_Worked_Examples.md` |
| **Applies to** | Retrieval-augmented generation systems delivering question-answering, search, or knowledge-assistant capabilities over a defined corpus |

---

## 1. Purpose

This playbook exists because RAG projects fail in predictable, recurring ways — and almost all of those failures trace back to questions that weren't asked early enough.

It is written for the **delivery lead** running a RAG initiative: someone responsible for translating sponsor intent into a working system. It assumes a multi-disciplinary delivery team (engineers, data, evaluation, governance, product) and the authority to set delivery cadence.

Three goals:

1. **Make the pre-build gate explicit.** No code is written until the Phase 0 questions are answered in writing.
2. **Standardise the build shape.** RAG systems share an abstract pipeline; deviation requires justification, not the other way around.
3. **Define ready and done.** Each delivery phase has clear entry and exit criteria, qualitative and quantitative. Skipping criteria is the highest-cost failure mode in this work.

This is not a project plan. Phases overlap; sequencing is contextual. The playbook captures what must be true, not what happens when.

---

## 2. Scope

**In scope.** Retrieval-augmented generation systems where:

- A defined corpus exists or can be acquired
- The primary user interaction is asking questions and receiving grounded answers
- The corpus and questions are in known languages
- Hallucination must be controlled and answers must be source-citable

**Out of scope.** Pure conversational AI (no corpus), agentic systems (autonomous tool use), fine-tuning programs, classification or structured extraction systems. Each has its own playbook shape and is best handled separately.

**Adjacent shapes covered partially.** RAG-augmented agents (agentic systems with retrieval as one tool) inherit the indexing-phase work in this playbook. Eval-only programs over a corpus inherit the quality-control framework.

---

## 3. Phase 0 — Pre-build decisions

The questions that must be answered in writing before Phase 1 Discovery is considered ready to start. These are not nice-to-haves; every one of them shows up later as a delivery risk if skipped.

The output of Phase 0 is a written **Pre-Build Decision Record** signed off by the sponsor and the delivery lead. Disagreements at Phase 0 are cheap; disagreements at Phase 5 cost weeks.

### 3.1 Problem framing

- **What is the problem being solved?** Stated in one sentence, no jargon.
- **Who is the user?** A specific role or persona, not "the business."
- **What does the user do today?** The alternative the system must beat. If there is no alternative, the success bar is different.
- **What does *good enough* look like?** Concrete, measurable. "Useful and accurate" is not an answer.
- **What does failure look like?** Three to five named failure modes, predicted in writing, retained for Phase 9 retrospective.

### 3.2 Corpus profile

- **What is the corpus?** Specific sources, named.
- **Who owns the source?** Licensing, attribution, refresh rights.
- **What format does it arrive in?** Markdown, PDF, HTML, structured records, mixed.
- **What language(s)?** Single-language systems are radically simpler than multilingual ones.
- **What size?** Number of records, total tokens, growth rate per month.
- **What quality?** Manually authored, auto-generated, mixed. Curated, edited, raw.
- **Does it contain PII or regulated content?** Affects every downstream decision.
- **How stable is it?** Stable, periodically updated, continuously changing. Drives refresh strategy.
- **Is it complete?** Or are there known gaps that will create user-visible failures?

### 3.3 Technical commitments

These decisions can be revisited later, but require justification to change. Commitment up front means the team aligns on the same architecture.

- **Embedding model.** General-purpose vs domain-specific, multilingual considerations, vendor.
- **Generator model.** Capability tier (frontier, mid, small), cost tier, fallback model.
- **Vector store.** Managed service vs self-hosted; expected scale; latency targets.
- **Indexing cadence.** One-time, scheduled, event-driven.
- **Chunking strategy intent.** Fixed-size, semantic, hybrid, structure-aware. Final choice empirical, but starting assumption committed.
- **Retrieval strategy intent.** Pure vector, hybrid (vector + keyword), with or without reranking.
- **Citation requirement.** Hard requirement (every claim cited), soft (citations where available), or none.

### 3.4 Quality contracts

- **What metrics define quality?** Faithfulness, relevance, completeness, citation accuracy, latency, cost. Pick three to five primary metrics.
- **What thresholds count as launch-ready?** Numeric where possible. "≥80% faithfulness on a 50-item golden set" beats "high faithfulness."
- **Who creates the golden set?** Domain expertise required. Cost and timeline implications.
- **Who judges quality at launch?** Human reviewers, automated metrics, both. Calibration plan.
- **How often is quality re-evaluated post-launch?** Weekly, monthly, on corpus refresh.

### 3.5 Governance and responsibility

- **Who owns the system after delivery?** Named owner with budget and decision authority.
- **What happens when the upstream model changes?** Drift detection, re-evaluation cadence, fallback plan.
- **What happens when the corpus changes?** Refresh process, re-indexing trigger, communication.
- **What regulatory frameworks apply?** Australian AI Safety Standard, ISO 42001, EU AI Act, industry-specific (APRA, healthcare, legal). Determines which Phase 7 controls are mandatory.
- **How are users informed they're interacting with AI?** Mandatory in most regulatory frameworks; affects UX.
- **What's the fallback when the system can't answer confidently?** Refuse, escalate to human, defer to alternative.
- **Where does data live?** Residency, sovereignty, cross-border transfer.

### 3.6 Sensitive content handling (mandatory if corpus is not fully public)

This sub-section is critical and easy to underestimate. PII baked into embeddings is functionally impossible to retract cleanly — the only real remediation is rebuilding the index from scratch. Decisions made here determine what's permissible downstream; Phase 7 hardening is *verification* of these controls, not first intervention.

- **What categories of sensitive content might exist in the corpus?**
  - *Direct identifiers* — names, emails, phone, address, DOB, government IDs (TFN, Medicare, passport, driver's licence)
  - *Indirect identifiers* — IP addresses, device IDs, account numbers, biometric data
  - *Sensitive information* (special category under Privacy Act / GDPR Art. 9) — health, racial/ethnic origin, religious belief, sexual orientation, political views, criminal history, financial position, union membership
  - *Confidential business data* — trade secrets, contracts, customer lists, pricing, strategic plans, M&A material
- **What lawful basis applies to processing this data?** Consent, contract, legitimate interest, legal obligation. Documented in writing.
- **What's the PII handling strategy per category?** Options: detect and redact, detect and pseudonymise, detect and anonymise, retain with controls, refuse.
- **What detection approach?** Regex (cheap, brittle), NER models (better recall), dedicated PII services (Microsoft Presidio, Azure AI Language PII, AWS Macie, Google DLP API — best practice for production).
- **Who approves the data handling approach?** Sponsor, Data Protection Officer, Legal, sometimes regulator. Approval chain documented before Phase 2 begins.
- **What's the audit trail requirement?** Every transformation logged; originals retained under stricter controls for reversibility.
- **Cross-border transfer implications?** Where physically does the corpus live; where do embeddings live; vendor's data-handling terms (does the embedding model provider retain or train on the data?).

### 3.7 Australian regulatory context (for Australian deliveries)

Frameworks likely to apply to Australian client work, named explicitly so they appear on the Phase 0 checklist rather than being discovered late:

- **Privacy Act 1988** (substantially amended 2024) and the **13 Australian Privacy Principles (APPs)** — APP 6 (use and disclosure) and APP 11 (security) bite hardest in AI contexts.
- **Notifiable Data Breaches scheme** — mandatory reporting of breaches likely to cause serious harm. AI systems that leak PII via generation are in scope.
- **APRA CPS 234 (Information Security)** and **CPS 230 (Operational Risk Management)** — financial services entities; information-asset management applies to AI training data and embeddings.
- **Voluntary AI Safety Standard (DISR, 2024)** — 10 guardrails; signals mandatory-standard direction. Many regulated entities adopting voluntarily.
- **Critical Infrastructure (SOCI) Act** — sector-specific obligations for energy, telecoms, financial services, healthcare, transport.
- **Industry-specific frameworks** — *My Health Records Act* (healthcare), *Banking Code of Practice* (banking), state HRIPAs (NSW, Victoria), others.

International overlay where applicable: **GDPR** (EU resident data), **EU AI Act** (high-risk AI systems serving EU users), **ISO 42001** (de facto international AI management system standard).

### 3.8 Scope and sequencing

- **Is this learning, prototype, MVP, or production?** Drives every subsequent decision.
- **What is the timeline?** With dependencies named.
- **What is explicitly out of scope?** As important as what's in scope.
- **What is the team shape?** Skills, headcount, availability, reporting lines.
- **What is the budget?** Build, inference, operations, support.
- **What does Phase 2 look like?** If this is Phase 1 of a longer roadmap, the Phase 2 vision constrains Phase 1 architecture decisions.

### 3.9 Phase 0 Definition of Ready and Done

**DoR (can Phase 0 start?)**

- A named sponsor with budget authority
- A stated problem, however vague
- Delivery lead identified and available

**DoD (is Phase 0 complete?)**

- Every question in sections 3.1 through 3.8 answered in writing
- For non-public corpora: sensitive content categories named, handling strategy documented, approval chain complete (§3.6)
- Applicable regulatory frameworks identified and acknowledged (§3.5, §3.7)
- Disagreements among stakeholders surfaced and resolved (or explicitly deferred with named trigger)
- Pre-Build Decision Record signed off by sponsor and delivery lead
- Predicted failure modes recorded (Phase 9 retrospective input)

---

## 4. The RAG pipeline — architectural reference

Every RAG system implements two phases: indexing (one-time per corpus version) and query (one per user question). The abstract steps are stable across projects; implementation varies.

### 4.1 Indexing phase

| # | Step | Input | Output |
|---|---|---|---|
| 1 | Source acquisition | Source identifier | Raw files on disk |
| 2 | Source preparation | Raw files | Records in standard shape `{id, title, path, content}` |
| 3 | Quality assessment | Prepared records | Sample reports, flagged issues |
| 4 | Chunking | Records | Chunks `{id, text, metadata}` |
| 5 | Embedding generation | Chunks | Vectors aligned to chunks |
| 6 | Index persistence | Chunks + vectors | Persisted vector index |

### 4.2 Query phase

| # | Step | Input | Output |
|---|---|---|---|
| 7 | Query reception | User question | Normalised query |
| 8 | Query embedding | Query string | Query vector |
| 9 | Similarity retrieval | Query vector | Top-k chunks |
| 10 | Context assembly | Chunks + query | Prompt with context |
| 11 | Generation | Prompt | Raw model output |
| 12 | Response formatting | Raw output + chunks | Answer with citations |

### 4.3 Contracts that must not break

Cross-step data shapes and function signatures. Internals of any module can change freely; these contracts require deliberate version migration.

- **Record shape** (step 2 → step 4): `{id: str, source_path: str, title: str, content: str}` minimum; additional metadata fields (timestamps, descriptions, content type) optional but recommended for production
- **Chunk shape** (step 4 → step 5/6): `{id: str, text: str, metadata: dict}` where metadata carries provenance for citation
- **Vector dimensionality** (step 5 → step 6): determined by embedding model; must be consistent between indexing and query
- **Retrieved chunk list** (step 9 → step 10): list of chunks including source metadata
- **Answer shape** (step 11 → step 12): includes raw text plus citation markers traceable to retrieved chunks

### 4.4 Implementation reuse profile (same problem, different corpus)

How much code carries forward unchanged when a new corpus enters the same RAG problem space.

| Step | Reuse | Notes |
|---|---|---|
| 1. Source acquisition | None | Pattern reuses; code rewritten per source |
| 2. Source preparation | None | Cleaning framework reuses; rules rewritten per markup |
| 3. Quality assessment | Partial | Tool architecture reuses; specific flags adjust |
| 4. Chunking | Full | Algorithms unchanged; chunk size tunes |
| 5. Embedding | Full | API wrapper unchanged; model name tunes |
| 6. Index persistence | Full | Vector store integration unchanged |
| 7. Query reception | Full | Input handling unchanged |
| 8. Query embedding | Full | Same module as step 5 |
| 9. Retrieval | Full | Query logic unchanged; k value tunes |
| 10. Context assembly | Partial | Template reuses; system prompt's domain framing rewrites |
| 11. Generation | Full | API wrapper unchanged; sampling tunes |
| 12. Response formatting | Partial | Citation logic reuses; metadata fields available adjust |

**Design implication.** Steps 4–9 and 11 are infrastructure. Time invested in clean interfaces here compounds across projects. Steps 1–2 are corpus-specific code that should be approached with the cleaning framework (four-category model, three-strikes principle) but rewritten each time. Steps 10 and 12 have a seam: the skeleton is shared, the project-specific content is loaded separately.

---

## 5. Quality controls per step

What can go wrong at each step, and the controls that big-company production RAG systems apply.

### Step 1 — Source acquisition

**Failure modes.** Stale corpus; missing sections; silent upstream format changes; ingesting wrong version.

**Controls.**

- Pin source versions (commit hashes, snapshot URLs, dated extracts)
- Document the source contract — what's expected, what's optional
- Schedule re-fetch and diff against last known state
- Alert on shape changes upstream (record count drops, field missing)

### Step 2 — Source preparation

**Failure modes.** Over-cleaning strips meaning; under-cleaning leaves noise that pollutes embeddings; cleaning rules silently fail on edge cases.

**Controls.**

- Sample before and after every cleaning rule (15+ random records)
- Cleaning framework: classify every transformation as semantic content / semantic metadata / authoring directive / cross-reference; treat differently
- Three-strikes principle: necessary, safe, tested before any rule ships
- Mark and skip rather than delete where possible; reversibility matters
- ADR every non-trivial cleaning decision

### Step 3 — Quality assessment

**Failure modes.** Issues hide in the long tail; random sampling misses systematic problems; flagging without action.

**Controls.**

- Stratified sampling: by content type, length bucket, source path — not pure random
- Named flag taxonomy with documented criteria
- Coverage metrics: what percentage of the corpus was sampled, with confidence implications
- Re-sample after every change to cleaning rules

### Step 4 — Chunking

**Failure modes.** Splits break sentences or sections; chunks too small lose context; chunks too large dilute retrieval signal; metadata stripped during chunking.

**Controls.**

- Respect natural boundaries: headers, paragraphs, list items, code blocks
- Overlap (10–20% typical) preserves context spanning chunk boundaries
- Preserve source metadata in every chunk for citation
- **Measure empirically.** Chunking strategy is the highest-leverage quality control in early iteration. Compare ≥2 strategies with measured retrieval and answer metrics before committing.

### Step 5 — Embedding generation

**Failure modes.** Indexing model differs from query model (recall craters silently); non-English content embedded with English-only model; rate limits cause partial indexing.

**Controls.**

- Version the embedding model in index metadata
- Use the same wrapper module for indexing and query — enforce by code structure
- Multilingual model when corpus or queries are non-English
- Retries with exponential backoff; explicit failure on persistent errors
- Batch with size limits aware of provider quotas

### Step 6 — Index persistence

**Failure modes.** Half-written index on failure; old index destroyed before new one verified; index schema drift.

**Controls.**

- Atomic builds: write to new location, verify, then rename
- Blue-green swaps: never destroy old until new is verified end-to-end
- Index versioning aligned with embedding model version
- Schema validation on every read

### Step 7 — Query reception

**Failure modes.** Prompt injection in user query; pathologically long queries; mid-query language switches; non-question inputs.

**Controls.**

- Length caps (configurable per deployment)
- Sanitisation: strip control characters, normalise whitespace
- Never blindly concatenate user input into prompts — always through a defined slot in the template
- Log queries for analytics, drift detection, attack pattern surfacing

### Step 8 — Query embedding

**Failure modes.** Different model used than for index (see step 5).

**Controls.**

- Same module as step 5 (enforced by import structure)
- Assert at startup that index metadata matches the embedding model in use; refuse to serve if mismatched

### Step 9 — Similarity retrieval

**Failure modes.** Top-k misses relevant chunks; near-duplicate chunks dominate; pure vector search misses keyword-specific queries; technical or rare-term queries fail.

**Controls.**

- **Hybrid search** (vector + BM25 keyword) — significantly better than vector-only for technical content
- **Reranking** with cross-encoder after initial retrieval — production-grade RAG uses two-stage retrieval (Bing Copilot, Perplexity, most enterprise systems)
- Diversity penalties (MMR, deduplication) to avoid near-duplicate dominance
- Measure both recall@k and precision against a ground-truth golden set
- Adjust k empirically; defaulting to 5 is conservative

### Step 10 — Context assembly

**Failure modes.** Token budget overruns truncate the most relevant chunk silently; citation metadata stripped so model can't attribute; system prompt insufficiently strong about grounding.

**Controls.**

- Explicit token budgeting with priority — best-ranked chunks survive truncation
- Structured prompt sections — separate instructions, context, and user query
- Firm grounding instruction: "Answer only using the provided context. If the context does not support an answer, say so."
- Citation markers embedded in chunks before prompt assembly
- Pre-flight: log token counts per query, alert on near-budget conditions

### Step 11 — Generation

**Failure modes.** Hallucination — model invents facts not in context; over-confidence on under-supported answers; refusal when context does support an answer; format drift breaking downstream parsing.

**Controls.**

- Low temperature for factual question-answering (0.0 to 0.3 typical)
- Prompt-level "I don't know" permission and instruction
- Structured output (JSON schema, tool-style response) when downstream parsing required
- Post-generation grounding check as backstop — verify cited content exists in retrieved chunks
- Logged generation parameters for reproducibility

### Step 12 — Response formatting

**Failure modes.** Citations don't trace to retrieved chunks (model hallucinated the citation); user can't verify source; metadata loss between generation and display.

**Controls.**

- Validate each citation against the retrieved chunk set; flag or reject orphaned citations
- Surface chunk identifiers in citations, not free-form text
- Expose retrieval confidence or grounding quality to user where feasible
- Render source links or paths visibly, not buried in metadata

---

## 6. Industry techniques worth knowing

Production-grade RAG systems use two techniques that are worth understanding by name, even if deferred to Phase 6 optimisation work.

**Contextual Retrieval.** Before embedding a chunk, prepend a short model-generated summary describing what document and section the chunk is from. Boosts recall significantly on technical corpora because chunks regain context lost during chunking. Cost: extra inference per chunk at index time; no query-time cost. Published by Anthropic, late 2024.

**Cross-encoder reranking.** Two-stage retrieval: bi-encoder pulls top-50 chunks fast, slower cross-encoder re-scores each against the query precisely, returning top-5. Standard pattern in Bing Copilot, Perplexity, most enterprise RAG. Cost: latency and inference per query; benefit: significantly improved precision.

Both are deferred Phase 6 work in most projects. Worth knowing they exist so the Phase 6 experiment design is deliberate.

---

## 7. Cross-cutting quality concerns

Four concerns that span every step and must be designed in, not bolted on.

**Evaluation is the only ground truth.** Every quality claim ("this chunking is better," "this prompt is better") is suspect without measurement against a golden set. The eval program is part of delivery, not afterthought. Recommended structure: golden set covers diverse query types; metrics include faithfulness, relevance, completeness, citation accuracy, latency, cost; LLM-as-judge calibrated against human labels at least once per project.

**Versioning everything that affects quality.** Embedding model, chunking strategy, prompt template, index schema, retrieval parameters, dependency versions, corpus snapshots. When quality regresses, the team must be able to trace what changed. This is a Phase 7 hardening concern; designing for it from Phase 3 makes Phase 7 cheap.

**Monitoring in production.** Drift detection (corpus, model upstream), query distribution analysis (user intent shifts), cost and latency tracking, refusal rate, citation accuracy spot-checks. Big companies bake this in from day one; retrofitting is painful. Mandatory before any production deployment for regulated industries.

**Regulatory considerations are a thread, not a phase.** PII handling, lawful basis, data residency, audit trails, access control — these weave through every phase from Phase 0 (decisions) through Phase 2 (data handling) through Phase 3 (architecture) to Phase 7 (verification). Deferring all of this to Phase 7 is the antipattern: PII baked into embeddings during Phase 5 cannot be removed cleanly without rebuilding the index. The cost of late-stage discovery is order-of-magnitude higher than early-stage design. For non-public corpora, regulatory thinking is Phase 0 work; Phase 7 confirms it worked, but cannot create it.

---

## 8. Definition of Readiness and Done per delivery phase

Mapped to the nine-phase methodology in `AI_Delivery_Lifecycle.md`. Each phase has qualitative checks (have we done X?) and quantitative checks (have we measured Y to threshold Z?).

### Phase 1 — Discovery & Scoping

**DoR.** Pre-Build Decision Record complete (Phase 0 DoD). Sponsor available for ≥2 working sessions.

**DoD.**

- Written framing document, readable by someone outside the team
- Three to five predicted failure modes documented
- Success criteria measurable; thresholds named
- Stakeholder agreement on scope, captured in writing
- Reproducibility plan: how the work will be regenerated end-to-end

### Phase 2 — Data & Knowledge Curation

**DoR.** Corpus source identified, access confirmed, licensing clear. For non-public corpora: Phase 0 §3.6 (sensitive content handling) complete; PII handling strategy documented and approved.

**DoD.**

- Reproducible pipeline producing the curated artifact (single command)
- Quality metrics: record count, length distribution, coverage by category
- Cleaning decisions documented (ADR per non-trivial rule)
- Spot-check completed via sampling tool; flagged issues triaged
- Quantitative: at least 30 random records inspected; flag rate documented
- **For non-public corpora:** PII detection pass executed *before* content cleaning; handling decisions applied and logged per category; sampling for missed PII completed as part of quality assessment; original retained under stricter controls for reversibility

### Phase 3 — Solution Architecture

**DoR.** Phase 1 and Phase 2 DoD complete. Cost and latency budgets known from Phase 0.

**DoD.**

- Stack documented with one-line rationale per choice
- Module boundaries and interface contracts written
- Every deferred decision tagged with named revisit trigger
- Architecture diagram interpretable by team members outside the original session
- External-dependency drift check: confirm selected SDKs and APIs are still GA, not deprecated

### Phase 4 — Ground Truth & Evaluation Design

**DoR.** Corpus curated (Phase 2 DoD). Architecture locked (Phase 3 DoD).

**DoD.**

- Golden set built and committed; size appropriate to project scale (30–50 for learning, 100s+ for production)
- Eval metrics documented with formulas
- LLM-as-judge calibration completed if used (human-label agreement measured on ≥20 examples)
- Baseline can be run end-to-end against the eval — no missing pieces
- Quantitative: ≥80% calibration agreement for LLM-as-judge before trusted; statistical confidence approach documented (not just averages)

### Phase 5 — Baseline Build

**DoR.** Phase 4 DoD complete (cannot baseline without a measurement substrate).

**DoD.**

- System runs end-to-end on the full golden set
- Baseline numbers captured, dated, in the repo
- Observed failure modes documented (more useful than the numbers)
- Repo state reproducible from fresh checkout
- Quantitative: at least one metric per primary quality dimension (faithfulness, relevance, latency, cost) recorded for baseline

### Phase 6 — Iteration & Optimisation

**DoR.** Phase 5 DoD complete; baseline exists.

**DoD.**

- Experiment log with before/after numbers for every change
- Winning configuration documented with rationale
- Known limits and remaining failure modes captured
- Cost and latency profile understood, not just quality
- Quantitative: improvement over baseline measurable and statistically meaningful, not within noise

### Phase 7 — Hardening & Trust

**DoR.** Phase 6 winning configuration locked. Threat model and compliance constraints known.

**DoD.**

- Every output traceable to inputs (citation enforcement working)
- Grounding check in place; hallucinations detected before user exposure
- Per-query observability: logging, tracing, cost, latency
- Cost controls: rate limits, budget alerts, fallback behaviour tested
- Security review complete; PII handling, injection resistance, auth verified
- Governance controls mapped to applicable framework (Australian AI Safety Standard, ISO 42001, etc.)
- Quantitative: hallucination rate under defined threshold; citation accuracy measured

### Phase 8 — Deployment

**DoR.** Phase 7 DoD complete. Hosting decision made; access model defined.

**DoD.**

- System accessible at stable URL or interface
- Documentation sufficient for a stranger to use it
- Deployment automated; reproducible from scratch
- Operational handoff to named owner complete
- Monitoring dashboards live

### Phase 9 — Retrospective & Handoff

**DoR.** Phase 8 DoD complete. The delivered system has been used by people outside the build team.

**DoD.**

- Case study written; situation, decisions, tradeoffs, outcomes
- Predictions-vs-reality diff against Phase 1 failure mode list
- Open issues tracked, not buried
- Methodology feedback fed back into `AI_Delivery_Lifecycle.md` and this playbook
- Lessons published or shared internally — knowledge transfer complete

---

## 9. RAG-specific risks and anti-patterns

Things that bite RAG projects specifically. Worth surfacing in Phase 0 and revisiting at Phase 9.

**Hallucination is the default, not the exception.** Without explicit grounding controls, the system will invent facts. Treat hallucination as expected and design to detect it, not avoid it through hope.

**Eval is harder than build.** The temptation to build first and "evaluate later" leads to optimisation against memory, not measurement. Phase 4 is non-negotiable.

**Chunking is the biggest quality lever and the easiest to under-invest in.** Most projects ship with the first chunking strategy they tried because comparison is tedious. The 15-30% recall improvements available from systematic chunking experiments rarely get realised.

**"Just add more docs to the corpus" is the trap.** Corpus quality dominates corpus quantity for RAG performance. A clean small corpus beats a noisy large one. Project sponsors will push for corpus expansion; the delivery lead pushes back when expansion compromises quality.

**Corpus drift makes yesterday's evals stale.** When the corpus is updated, the golden set may no longer reflect current content. Re-validation cadence is a Phase 7 concern that often gets deferred to "after launch" and then never happens.

**Citation accuracy is separate from answer accuracy.** A correct answer with a fabricated citation is worse than a refusal — it destroys user trust. Validate citations independently of answer quality.

**Refusal is a feature, not a failure.** Systems that always answer are worse than systems that know when to refuse. Optimise refusal calibration alongside answer quality.

**The system that wins evals is not always the system users prefer.** Production RAG quality includes UX, response time, refusal handling, and trust signals — not just answer correctness. Eval-only optimisation ships systems that score well and disappoint users.

---

## 10. How to use this playbook

**At project start.** Read sections 1–3. Run Phase 0 as a workshop with sponsor and team. Produce the Pre-Build Decision Record. Do not begin Phase 1 until Phase 0 DoD is satisfied.

**During delivery.** Reference section 4 for the architectural blueprint. Reference section 5 for quality controls when making implementation decisions. Reference section 8 for phase entry and exit criteria — these are the project's quality gates.

**At project close.** Run the Phase 9 retrospective. Feed any methodology gaps surfaced back into this playbook and into the parent `AI_Delivery_Lifecycle.md`.

**Between projects.** This playbook is intended to evolve. Every project should leave it slightly better than it arrived — clearer in places that confused, tightened where it was vague, extended where it was silent. Version increments after each delivery cycle.

---

## 11. Changelog

| Version | Date | Notes |
|---|---|---|
| 0.1 | 2026-05-30 | Initial draft. Phase 0 articulated with dedicated sensitive-content sub-section (§3.6) and Australian regulatory context (§3.7). Pipeline reference, quality controls, DoR/DoD per phase, RAG-specific risks. Regulatory considerations promoted to fourth cross-cutting concern. Phase 2 DoD includes PII pre-pass requirement for non-public corpora. To be refined as foundry-doc-assistant and subsequent projects expose gaps. |

---

*This playbook evolves with each project it shapes. The version above reflects a single delivery in flight; the version that becomes a publishable artifact will have been hardened by three or more.*
