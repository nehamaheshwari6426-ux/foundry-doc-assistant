# AI Delivery Lifecycle — Observations & Working Notes

A running log of observations from real practice that inform the methodology's next iteration. Raw notes, not polished writing. Add liberally; trim never.

| | |
|---|---|
| **Status** | Living document |
| **Companion to** | `AI_Delivery_Lifecycle.md` |
| **Started** | 2026-05 |

---

## How to use this

- **Capture liberally.** Anything that surfaces during real work — frictions, wins, things that didn't translate from theory to practice. Future you can't reconstruct what current you noticed.
- **Don't pre-edit.** Notebook, not publication. Polishing happens when observations roll up into v0.X of the methodology.
- **Review periodically.** After each phase of a real project, or quarterly. Roll the high-impact observations into a methodology version bump.
- **Observations stay even after they're actioned.** Marked, not deleted — the history of how the methodology evolved is itself evidence of its maturity.

---

## 2026-05-17 — Methodology purpose, sharpened (PM reframe)

**Source.** Conversation while drafting v0.1 methodology, during Week 2 of foundry-doc-assistant build.

**Observation.** The methodology isn't just a "how to deliver AI" document. From a project-management perspective, its value is:

- **Predictable execution** — same steps every time, different context.
- **Optimised cost over time** — teams get faster as they repeat the cycle.
- **Easier risk surfacing** — risks recur per phase; identifying them becomes pattern matching.
- **Scope discipline** — phase boundaries make "is this in scope" answerable.

The underlying insight: teams work better when the *structure* is constant and only *context* and *details* change per project. This is a project-management truth, not just an AI truth.

**Methodology impact.**

- v0.1's Section 1 (Purpose) frames the methodology around legibility, skip-prevention, and decision defensibility. It should *also* explicitly frame it as a **repeatability framework** — the PM angle is currently absent.
- Add a stronger pitch for *why teams adopt this*: easier planning, faster over time, risks caught earlier, scope held. These are the buyer's words for why the methodology is worth using — sponsors, CTOs, delivery directors hear it this way.
- Possible new principle for Section 2: "Repeatability is the asset. The same structure across projects is what compounds. Variation belongs in the details, not the framework."

**Status.** Captured. Targets v0.2 (Section 1 reframe, possible new Section 2 principle).

---

## 2026-05-17 — Translating theory to first project

**Source.** Same conversation. Direct user quote: *"Starting from scratch I am finding it hard to visualise the process of delivering my first project and how that translates to a real world problem."*

**Reading.** The methodology doc has structure (phases, principles, anti-patterns) but no worked examples. A first-time user has to translate every abstract phase description into concrete work themselves. That's a real cognitive overhead, and it's a methodology gap, not a reader gap.

**Methodology impact.**

- v0.1 needs worked examples. Two flavours are useful: *(a)* what each phase looks like in this learning project (foundry-doc-assistant); *(b)* what each phase looks like in a representative enterprise project (e.g., internal RAG over policy docs at a mid-market financial services firm).
- The worked examples become the differentiator. Generic methodology docs exist; ones with credible side-by-side learning-vs-enterprise examples don't.
- Tactical fix: add a "Concrete example" sub-block under each phase header. Two short paragraphs. Learning project on the left, enterprise project on the right.
- Strategic: as more projects run through the lifecycle, the example library grows. By v1.0 it's not 2 examples per phase but 5-10 — that's when the methodology becomes self-evidently useful.

**Status.** Captured. High-priority action — worked examples are the missing link for v0.1 actually being usable as a planning template.

---

## 2026-05-17 — Roles needed for team-ready use

**Source.** Same conversation.

**Observation.** The methodology will be used in real delivery teams, not just by a solo practitioner. Role definitions are needed for the methodology to be team-ready.

**Methodology impact.**

- v0.1 deliberately omitted roles. v0.2 should include them — ~8-10 roles mapped to phases (Sponsor, Product Owner, AI Delivery Lead, Solution Architect, Data/ML Engineer, AI Engineer, Evaluation Lead, Domain Expert/SME, Responsible AI Lead, Platform/Ops Engineer).
- Section placement: new Section 5 (Roles & Responsibilities), before Project-type Adaptations.
- Per-phase: add a one-line "primary roles" tag at the top of each phase block for quick reference.
- Critical detail: include explicit fractional/solo-practice notes. One person plays multiple roles in small teams; the methodology must work for both shapes.

**Status.** Captured. Targets v0.2.

---

## 2026-05-17 — Separation of methodology from project

**Source.** Discussion of where the lifecycle content should live.

**Observation.** The methodology shouldn't be embedded in any single project's README — it should be a separate, standalone document that projects reference. Burying it in one project under-sells it as a standalone artefact and over-couples it to a specific project's framing.

**Methodology impact.**

- v0.1 lives correctly as a separate document. Projects link to it with a one-line reference.
- When publishing publicly later: the methodology gets its own URL/repo/article, not a section in a project repo.

**Status.** Acted on. Methodology is now its own file.

---

## 2026-05-22 — Goal of cleaning, and the cleaning strategy framework

**Source.** Saturday session, Week 3 of foundry-doc-assistant. Spot-check pass surfaced two cleaning regex bugs (image without alt-text; `:::zone` with leading space). Direct user question that followed: *"How does one decide what to keep vs strip during cleaning?"* Then: *"How would you define the goal of data cleaning?"* The conversation worked toward an explicit goal definition and a small framework.

**Observation.** Phase 2 in v0.1 says "acquire, clean, and structure" — that's a *what*, not a *why*. Teams without a clear goal definition for cleaning end up either over-cleaning (losing answerable content) or under-cleaning (carrying noise that degrades retrieval). The methodology should state the goal of cleaning explicitly, then equip teams with a small set of categories and tests to apply consistently.

**Methodology impact.** Three additions for v0.2, all anchored to Phase 2.

### 1. Goal-of-cleaning statement (proposed addition to Phase 2 Purpose)

> Produce a corpus that lets the downstream system give correct, complete answers — and lets you measure whether it does. The cleaned corpus should be the *smallest, most reproducible* representation of the source that still supports the *full range* of correct answers users will need.

Unpacked into four operational requirements:

1. **Preserve answerability.** A question answerable from the original content must remain answerable from the cleaned content.
2. **Remove noise that degrades retrieval or generation.** Authoring directives, layout markers, and repeated boilerplate compete with semantic content in the embedding space without adding meaning.
3. **Make the corpus reproducible and inspectable.** A cleaning step you can't rerun or sample is technical debt.
4. **Preserve eval honesty.** Aggressive cleaning can artificially inflate eval scores; over-conservative cleaning can depress them. Clean enough that the eval measures what the system can actually do for real users — no more, no less.

### 2. Four-category content framework (proposed sub-section of Phase 2 Key activities)

Every piece of source content falls into one of four categories, each handled differently:

| Category | Examples | Treatment |
|----------|----------|-----------|
| **Semantic content** | Prose, code, examples, tables | Keep verbatim |
| **Semantic metadata** | Image alt text, alert type, code language | Keep, normalised |
| **Authoring directives** | Layout markers, build hints, frontmatter | Strip — readers never see them |
| **Cross-references** | Transclusions (e.g. INCLUDEs), xrefs | Resolve if target is in corpus; accept loss if not |

**The "is it cleaning?" test:** *Would removing this change the meaning of the page for a reader?* If yes — keep. If no — strip. Everything else is refinement.

### 3. Three-strikes principle for cleaning rules (proposed Phase 2 sub-principle)

A cleaning rule earns its place only when it is:

1. **Necessary** — the pattern actually appears in the corpus (don't pre-emptively strip stuff that isn't there).
2. **Safe** — stripping it doesn't change page meaning for a reader.
3. **Tested** — a spot-check after applying confirms (1) and (2).

Cleaning bugs are usually one of these three failing. Evidence from this project:

- The original `INCLUDE` rule failed #2 (changed page meaning by losing transcluded content) → switched from strip to resolve.
- The `:::zone` regex failed #1 (pattern was wrong on the with-space variant) → tolerated optional whitespace after `:::`.
- The image regex failed #1 (pattern only matched images with `alt-text`; icon/banner images slipped through) → split into two patterns.

**Status.** Captured. Targets v0.2 of `AI_Delivery_Lifecycle.md` — three concrete additions, all in Phase 2.

Also adds a tactical sub-rule: **re-spot-check after every cleaning change.** Fixing one bug routinely surfaces the next; one-and-done verification is insufficient.

---

## 2026-05-24 — Phase 2 needs an upstream-survey step before pipeline design

**Source.** Phase 1-2 retrospective for foundry-doc-assistant. The `articles/ai-foundry/` → `articles/foundry/` consolidation upstream was discovered *after* the acquisition pipeline was scoped. Cost ~30 minutes of diagnosis. A 5-minute browse of `MicrosoftDocs/azure-ai-docs` at the start of Phase 2 would have surfaced it immediately.

**Observation.** v0.1 Phase 2 jumps from project framing to acquisition pipeline design. Real sources change shape (consolidations, deprecations, reorganisations) and the acquisition pipeline is the most expensive thing to retrofit. A cheap upstream survey before pipeline design catches these surprises while they're still free.

**Methodology impact.** v0.2 Phase 2 should add an explicit **Upstream survey** step as the first key activity — before "Acquisition pipeline." Suggested wording:

> *Survey the source repository or system at its current state.* Browse the actual directory structure or schema; identify any recent reorganisations, consolidations, or deprecations; note licensing and access constraints. 5–15 minutes of upfront survey routinely saves hours of pipeline rework.

**Status.** Captured. Targets v0.2 Phase 2.

---

## 2026-05-24 — Quality verification needs a sampling tool, not just discipline

**Source.** Building `scripts/inspect_records.py` (manual review helper for cleaned corpus records) during Saturday session, after spot-check practice had repeatedly caught cleaning bugs.

**Observation.** The methodology currently treats sampling/spot-checking as a discipline ("spot-check 15 random records"). In practice, doing this without tooling is high-friction enough that teams skip it — particularly under time pressure. A small sampling tool with built-in heuristic flags (leftover syntax, length-ratio drops, missing titles) makes the verification cheap enough that it actually happens. The tool also makes findings reproducible via seeded sampling.

**Methodology impact.** Two additions for v0.2 Phase 2:

1. **Exit criterion** should specify *automated sampling plus eyeball review*, not just eyeball review:

   > Inspect a random sample (≥10 records) using a scripted sampling tool that flags structural anomalies (leftover source syntax, suspicious length ratios, missing metadata). The tool surfaces candidates; the eye is still the judge.

2. **Tooling note** in Phase 2 key activities: *Build the sampling tool early — before the full corpus is generated, not after the first eval fails.*

**Status.** Captured. Tool itself (`inspect_records.py`) is project-specific; the methodology lesson is general.

---

## 2026-05-24 — Re-spot-check after every cleaning change

**Source.** Two cleaning bug cycles on foundry-doc-assistant in W2-W3: INCLUDE-resolution bug → fix → spot-check → caught `:::zone`/image regex bugs → fix → spot-check confirms clean. Pattern was: each fix surfaced the next problem.

**Observation.** Cleaning bugs cluster. Fixing one routinely surfaces the next, because the original bug was masking output that contains the next failure pattern. One-pass spot-check (do once, declare done) misses this. Re-spot-check after every meaningful cleaning change is the actual discipline that catches the iceberg.

**Methodology impact.** Add a tactical rule to v0.2 Phase 2:

> *Every change to cleaning logic triggers another spot-check pass.* This isn't optional; cleaning bugs almost always cluster, and one-pass verification is insufficient. Budget for 2-4 cleaning iterations in Phase 2, not one.

**Status.** Captured. Targets v0.2 Phase 2 (likely as a paragraph under the Goal-of-cleaning section, or as a Common failure mode "one-pass verification").

---

## 2026-05-24 — Bias and safety belong in Phases 1-2-4, not just Phase 7

**Source.** W3 Saturday session, mid-brain-dump. Direct question: *"How do we ensure the data after cleaning is not biased and is safe to use?"* The question surfaced that v0.1 puts bias and safety concerns predominantly in Phase 7 (Hardening & Trust), which is too late — most bias originates upstream in Phases 1 (scope) and 2 (curation).

**Observation.** Treating bias and safety as a Phase 7 concern means rediscovering scope and curation decisions at hardening time, with much less leverage to change them. The earlier these are surfaced, the cheaper to mitigate. For the foundry-doc-assistant project specifically, four bias sources exist before Phase 7 even starts:

- **Source bias** (Phase 1) — Microsoft's docs reflect Microsoft's framing. Partly the point, partly a known limitation. Visible only if scoped consciously.
- **Scope bias** (Phase 1) — excluding API reference was a deliberate choice; the bias is documented in ADR 0001. Defensible only because it's named.
- **Cleaning-induced bias** (Phase 2) — INCLUDE resolution amplifies frequently-transcluded content; some snippets appear across many records.
- **Distribution bias** (Phase 2) — topics covered unevenly across `articles/foundry/` subdirectories will produce uneven retrieval quality.

And four cheap safety checks that belong at Phase 2 exit:

- PII scan (regex pass for emails, phones, card patterns)
- Prompt-injection pattern check
- Currency distribution sample (using `ms_date` frontmatter where available)
- Source attribution verifiability (every record traceable to a real upstream page)

**Methodology impact.** v0.2 should treat bias and safety as a **cross-cutting concern** with explicit touch-points across phases, not a Phase 7 single-block. Proposed additions:

1. **Phase 1 — new key activity:** *Bias surface area review.* Identify what the chosen scope systematically over- or under-represents. Document as a known limitation, not a bug.

2. **Phase 2 — new exit criterion:** *Conduct a bias and safety scan before exiting Phase 2.* Minimum checks: PII scan, prompt-injection pattern check, currency distribution, topic distribution. Document findings and any deferred mitigations with revisit triggers.

3. **Phase 4 — new key activity:** *Golden set bias check.* Verify the golden set covers the bias surface area identified in Phase 1 — including questions that probe known-weak areas, not just easy hits.

4. **Phase 7 — refocus:** rather than carrying all responsible-AI work, Phase 7 *enforces* the cross-cutting decisions made earlier (citation discipline, refusal behaviour, audit trails). It's the implementation layer for the responsibility decisions made upstream.

This may justify a small new section in the methodology — `**Cross-cutting concerns**` — outlining how bias, safety, governance, and observability thread through phases rather than living in one block.

**Status.** Captured. Targets v0.2 — bigger structural change than the cleaning additions. May warrant its own section/architecture in the methodology rather than just phase-by-phase tweaks.

---

## 2026-05-24 — Foundation: end-to-end delivery, compounding quality, measurable phase completion

**Source.** W3 Saturday session closing reflection. Direct user articulation: *"I felt I was approaching this through a software engineering and project management mindset, but what I have realised is that it requires a lot of end to end observation and making sure everything fits in well."* And: *"I am keen to unwrap all those measures and create a simple methodical process that can work as an end to end process to deliver an AI solution confidently."* And: *"some can corner cut and reduce the overall result by skipping measures and checking if each process step can be measured qualitatively and quantitatively as complete."*

**Why this is different from other observations.** The earlier entries in this log are tactical — fixes and refinements to specific phases. This is foundational — an organizing principle the methodology should be built around. Treating it as another dated entry under-sells it.

**Three foundational principles articulated:**

1. **AI delivery is a delivery problem with technical sub-problems**, not a technical problem with delivery wrappers. The technical work (corpus, embeddings, retrieval, generation) serves broader outcomes (trust, safety, customer experience, compliance) — not the other way around. Most teams optimise technical quality and assume delivery quality follows. It doesn't.

2. **Quality compounds across phases.** A Phase 2 bias issue isn't caught at Phase 2 — it surfaces as bad answers at Phase 6, gets misdiagnosed as a retrieval problem, and burns a week of iteration before someone traces it back. The methodology earns its keep by catching issues at the phase where fixing them is cheapest, which is almost never the phase where they manifest. Confirmed in this project — the INCLUDE bug would have been a Phase 6 mystery without the Phase 2 spot-check practice.

3. **Measurable completion per phase is the anti-corner-cutting mechanism.** Most methodologies have phases but lack rigor about what "done" means per phase. "Phase 2 complete" is usually vibes. Without measurable completion gates, corner-cutting is invisible and compounds. The methodology must specify qualitative *and* quantitative tests for each phase boundary.

**The concrete mechanism: Definition of Ready (DoR) and Definition of Done (DoD) per phase.**

- **DoR** = the contract for *starting* a phase. What inputs, prior-phase outputs, decisions, and resources must exist before this phase can productively begin. If DoR isn't met, the phase will produce flawed outputs.
- **DoD** = the contract for *exiting* a phase. What artifacts, measurements, and quality demonstrations must exist before the phase is considered complete. DoD includes both qualitative checks (e.g., "spot-check confirms cleaning preserves answerability") and quantitative thresholds (e.g., "≥10 random records inspected, ≤0 leftover syntax patterns").

These map onto the existing Phase 4 sub-block structure (Inputs, Exit criteria) but tighten them from descriptive to contractual. A phase isn't "in progress" until DoR is met; a phase isn't "complete" until DoD is verified.

**Methodology impact — this becomes v0.2's organising spine, not just an additional section.**

Proposed structure for v0.2:

1. **New Section 2.5 (or similar): Foundations.** Articulates the three principles above as the *why* underneath the methodology's *what*. Distinct from Section 2 (Principles), which is tactical. Foundations is strategic — the answer to "why this methodology vs CRISP-DM or MLOps?" when a CTO asks.

2. **Restructure every Phase block to include explicit DoR and DoD.** Replace or supplement the current `Inputs` and `Exit criteria` with `Definition of Ready` and `Definition of Done`, each split into qualitative checks and quantitative thresholds. Existing content gets restructured, not discarded.

3. **Cross-cutting concerns section** (the bias/safety observation logged earlier) lives naturally inside the Foundations framing: "What threads across phases vs what belongs to one."

**Status.** Captured as foundational-tier. Targets a substantial v0.2 restructure, not a tweak. Full drafting deferred to a future fresh-energy session. The thinking captured here is sufficient to retain the framing across the gap.

**Future work — possible separate document:** `AI_Delivery_Lifecycle_Foundations.md` may eventually warrant its own file if v0.2 doesn't comfortably hold it. Decide when drafting v0.2.

---

## 2026-05-24 — Milestone: first LinkedIn post published

**Source.** Saturday session, W3 of foundry-doc-assistant build.

**Observation.** Published the first LinkedIn post under the Year 1 visibility track — covering the `articles/foundry/` consolidation finding from W2 reframed as a lesson about silent assumptions in AI delivery. Audience-shifted from technical to business/AI-Lead readership during drafting. Post is live; engagement signal not yet meaningful.

**Methodology impact.** Not directly. But worth marking because:

- The visibility track was the most-deferred Year 1 stream until this point — twice deferred during W2-W3 sessions.
- First posts have outsized leverage: they establish voice, anchor early-follower expectations, and create the first traceable artifact when a hiring manager checks the LinkedIn profile.
- The drafting process itself surfaced an important calibration: my own drafts read too technical; user-led revision shifted to business framing; final LinkedIn-assisted version drifted further toward LinkedIn-formal. Worth noticing the gradient between *authentic voice* → *audience-adjusted* → *platform-flattened*. Future posts should stop at audience-adjusted.

**Status.** Logged as a milestone, not an action item. Public artifacts to be tracked in a separate log file.

---

## 2026-05-30 — Milestone: Azure Foundry wired and smoke-tested

**Source.** Saturday session, W3 of foundry-doc-assistant build. Final blocker to Phase 5 baseline build.

**Observation.** Provisioned a Microsoft Foundry resource (`foundry-nm-portfolio`, East US) with two model deployments: `gpt-4o` (generator) and `text-embedding-3-small` (embedding), both at Standard SKU. Wired Python configuration via `dotenv` and the stable OpenAI SDK pointed at Foundry's `/openai/v1` endpoint. Smoke test confirms both deployments respond correctly — chat completion returns expected reply, embedding returns a 1536-dimension vector confirming the right embedding model is in place.

**Methodology impact.** One v0.2 candidate worth noting: Microsoft deprecated the classic `AzureOpenAI` Python client SDK in favour of the OpenAI v1 endpoint *between* Phase 3 (architecture lock-in in W2) and Phase 5 (build start, now). The methodology should encode a *"validate selected SDKs are still GA before Phase 5 starts"* revisit trigger to catch platform-evolution drift between phases. This is a different shape of revisit-trigger than the model-comparison ones already in ADR 0001 — it's about *external dependency drift*, not internal capability tuning. Worth a small explicit category in v0.2's Phase 3 revisit-trigger guidance.

**Status.** Phase 5 baseline build now genuinely unblocked. Infrastructure complete; remaining W4 work is squarely the project, not setup.

---

## 2026-05-30 — Milestone: registered for Melbourne AI meetups (W1 deliverable closed)

**Source.** Saturday session, W3. Closing an outstanding W1 deliverable three weeks late.

**Observation.** Registered for multiple upcoming Melbourne AI meetups via Meetup.com / Eventbrite / LinkedIn Events. The W1 plan called for "sign up for one Melbourne AI meetup happening in the next 60 days" — that's now done. The original deferral was rationalised as a five-minute task that kept slipping; the actual blocker turned out to be an unsurfaced constraint (most meetups start after 5pm, which doesn't fit the available evenings reliably).

**Methodology / Year 1 plan impact.** Two patterns worth recording:

1. **Unsticky tasks need explicit scheduling, not just willpower.** Project work and LinkedIn posts compound (each session leaves a visible artifact). Meetup signups, cert modules, and Pty Ltd admin don't — they have small per-session payoff and no immediate gratification. The Year 1 Plan should treat these differently: schedule first in a session (when energy is highest), or pair with sticky tasks (do the AI-103 module while waiting for a long-running script). Just listing them as a "Thursday slot" relies on willpower that obviously hasn't shown up.

2. **The plan's proxies need to match the practitioner's constraints.** "Attend 4 meetups" is a *proxy* for "build local AI community visibility." If the proxy doesn't fit (evening constraints), the right move is to find another path to the underlying goal — Saturday workshops, online communities, 1-on-1 coffees, internal Telstra events — not to keep deferring the proxy. Plans should be auditable against the goal, not against the proxy.

**Status.** Closed for W1. Carries one Year 1 Plan revision: meetup target may need supplementing with non-evening visibility channels if evening attendance remains constrained.

---

## 2026-05-30 — Regulatory considerations are Phase 0 and Phase 2 work, not Phase 7 work

**Source.** Saturday session, W3. Question raised about what to consider for regulatory exposure (PII, sensitive content) during data processing phases.

**Observation.** The common industry pattern of *"we'll handle compliance during hardening"* is structurally too late for RAG systems. By Phase 7 (hardening), the corpus is already indexed and embedded with whatever it contained. PII baked into embeddings is functionally impossible to retract cleanly — the only real remediation is rebuilding the index from scratch, which is expensive and surfaces *which* records contained the leak only by re-running the detection pass.

Regulatory considerations belong earlier in the lifecycle:

- **Phase 0 (Pre-build)** — lawful basis, regulatory frameworks applicable, PII handling strategy, approval chain. Decisions made here determine what's permissible to even attempt downstream.
- **Phase 2 (Data Curation)** — PII detection and handling as a *parallel sub-pipeline* to content cleaning, run before chunking begins. Logged handling decisions per category. Reversibility through controlled retention of originals.
- **Phase 3 (Architecture)** — vendor data-handling terms, encryption, data residency, access control patterns baked into the stack choice.
- **Phase 7 (Hardening)** — *verification* that earlier controls work as intended, not first intervention.

**Methodology impact (high, structural).** Three concrete changes for v0.2 of both `AI_Delivery_Lifecycle.md` and `RAG_Solution_Delivery_Playbook.md`:

1. **Phase 0 of the playbook needs a dedicated sensitive-content sub-section.** Current Phase 0 (§3.5 Governance) asks "what regulatory frameworks apply?" — necessary but not sufficient. Add: categories of sensitive content present, lawful basis, PII handling strategy, approval chain.

2. **Phase 2 of the methodology needs a parallel PII handling sub-step.** Currently Phase 2 focuses on cleaning. For regulated corpora, PII detection runs *before* content cleaning rules apply, with its own quality assessment in step 3.

3. **The cross-cutting concerns section needs explicit treatment of "regulatory considerations are not a phase, they're a thread."** Like evaluation, versioning, and monitoring (already covered), regulatory thinking weaves through every phase. Bolting it on at Phase 7 is the antipattern.

**Australian context worth banking for client work.** Frameworks the v0.2 playbook should name explicitly: Privacy Act 1988 (and 2024 amendments) plus the 13 Australian Privacy Principles; Notifiable Data Breaches scheme; APRA CPS 234 and CPS 230 for financial services; Voluntary AI Safety Standard (DISR 2024); Critical Infrastructure (SOCI) Act; industry-specific frameworks (My Health Records Act, Banking Code of Practice, state HRIPAs). International overlay: GDPR, EU AI Act, ISO 42001.

**foundry-doc-assistant implication.** Corpus is Microsoft public documentation; zero PII, zero regulated content, zero exposure. Document this as a single-line statement in the Phase 0 record. The observation is methodology IP, not project work.

**Status.** Observation logged. Targets v0.2 of both methodology and playbook (substantial restructure rather than incremental update).

---

## 2026-05-30 — Cost economics belongs at every phase, not just Phase 7

**Source.** Saturday session, W3. Question raised about when cost decisions enter the methodology.

**Observation.** The current playbook treats cost as a scope concern (§3.6) and a Phase 7 hardening concern (cost-per-query observability). Both are necessary; neither is sufficient. Cost is a *contract*, not a scope detail, and it's a *thread*, not a phase — same shape as regulatory considerations and evaluation.

Each phase has its own kind of cost decision:

- **Phase 0** — cost budget, per-query ceiling, cost-vs-quality philosophy
- **Phase 1** — use-case cost validation; does the unit economics work?
- **Phase 2** — one-time corpus processing cost; matters for large corpora
- **Phase 3** — model and infrastructure cost commitments (biggest lever, hardest to reverse)
- **Phase 4** — eval cost budget; running golden sets with LLM-as-judge is not free
- **Phase 5** — measure baseline cost end-to-end; instrument from day one
- **Phase 6** — every experiment measured on cost alongside quality
- **Phase 7** — rate limits, alerts, fallback behaviour when over budget
- **Phase 8** — operating cost forecast at projected volume
- **Phase 9** — actuals vs forecast; lessons for next project

**Cost stack worth naming explicitly** (often missed in initial estimates):

- *Indexing-side one-time*: corpus acquisition, preparation, embedding generation, index storage
- *Query-side recurring*: query embedding, retrieval, reranking, generation, observability
- *Hidden costs*: eval running, failed requests, drift detection, re-indexing, development experiments, cross-region transfer
- *Capability costs that shape trajectory*: model tier, embedding dimensionality, vector store tier, reranking, caching

**Industry patterns worth banking for playbook v0.2:**

- Sponsor commits to per-query cost target and monthly operating budget at Phase 0
- Cost-aware architecture: mid-tier models for most queries, frontier for hard cases (routing logic)
- Caching as first-class architectural component (40-70% hit rates are normal in mature systems)
- Cost as a quality signal — spikes indicate model drift or query distribution drift
- Eval treated as its own budget line, with separate "fast eval" vs "release eval" tiers
- Rate limits, fallbacks, graceful degradation rather than uncapped spend

**Australian-context overlay:** Data residency may force older/slower regional models or premium tiers; APRA audit and logging requirements add ~20-30% infrastructure cost over baseline. Worth flagging in Phase 0 economic analysis for regulated client work.

**Methodology impact (high, structural).** Three concrete changes for v0.2:

1. **Phase 0 needs a dedicated cost contract sub-section.** Currently cost is scattered across §3.4 (quality contracts) and §3.6 (scope). Promote to its own sub-section with explicit questions: per-query target, monthly budget, indexing budget, eval budget, cost-vs-quality philosophy, approval chain for overruns.

2. **Cost economics becomes the fifth cross-cutting concern.** Same shape as evaluation, versioning, monitoring, regulatory — weaves through every phase. The "defer to Phase 7" antipattern matches the regulatory antipattern documented earlier today.

3. **Phase 5 DoD must include cost baseline.** Currently mentions "metric per primary quality dimension" — add "cost per query measured end-to-end and recorded against Phase 0 budget." Without Phase 5 cost baseline, Phase 6 iteration can't be cost-aware.

**foundry-doc-assistant context.** Project has been doing cost discipline well without naming it: pre-commit cost check via smoke test ($0.036 estimate before bulk indexing), API reference filter saves real money on re-index, version pinning prevents silent cost drift, `EmbeddingStats` dataclass is production-grade cost observability. What was missing: explicit cost budgets and assumptions in writing. ADR 0009 formalises this for the project.

**Status.** Observation logged. Targets v0.2 playbook (substantial Phase 0 expansion + fifth cross-cutting concern). ADR 0009 captures project-specific cost posture for foundry-doc-assistant.

---

## Pending themes (not yet enough evidence to act)

Patterns that have surfaced but need more practice data before becoming methodology changes:

- **Visual representation.** Phase summary tables, collapsibles, and flow diagrams have proven useful when drafting. The methodology doc itself may benefit from richer visuals beyond the current ASCII flow.
- **Buyer-facing framing.** Teams adopt methodologies because they make delivery cheaper/safer/more legible. The methodology's *external* framing (used in proposals, sales conversations, talks) may need to diverge from its *internal* framing (used by delivery teams running it). Two voices, same content.
- **Phase 4 exit criteria specifics.** Generic "golden set of appropriate size" is currently vague. Real projects will reveal what "appropriate" means by domain and risk level.

---

## Methodology version targets (working draft)

What each future version should address, based on observations to date:

- **v0.2** — **Substantial restructure, not incremental update.** Add Foundations section articulating the three foundational principles (delivery-first, compounding quality, measurable phase completion). Restructure every Phase block to use explicit Definition of Ready / Definition of Done with both qualitative checks and quantitative thresholds. Add cross-cutting concerns section threading bias/safety/governance through phases. Plus the previously-noted Phase 2 expansions: goal-of-cleaning statement; four-category content framework; three-strikes principle; upstream-survey step; spot-check exit criterion via sampling tool; re-spot-check after every cleaning change. Plus PM/repeatability angle in purpose; Roles & Responsibilities section; concrete examples per phase. *Targeted after foundry-doc-assistant Phase 5 complete.*
- **v0.3** — Worked-example appendix with full side-by-side: learning project vs enterprise project. *Targeted after one additional project run through the lifecycle.*
- **v0.4** — Richer visuals (phase flow diagram, role-phase matrix). *Targeted Year 2.*
- **v1.0** — Public release. Refined across at least 3 project runs with documented retrospectives. *Targeted Year 2-3.*

---

*Observations roll up into versions. Versions roll up into a methodology with a name and a reputation. Year 4-5 outcome: this is the framework your name is associated with — and these are the working notes that show how it was earned.*
